#include "4.4.6.h"
void func1(void)
{
    x++;
    y++;
    ch++;
    printf("in file2 x=%d,y=%d,ch is %c\n", x, y, ch);
}