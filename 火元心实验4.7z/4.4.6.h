#include <stdio.h>
int x, y;
char ch;